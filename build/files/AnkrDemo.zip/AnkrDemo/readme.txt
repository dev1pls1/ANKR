1.	Install the Intel SGX windows SDK "Intel(R)_SGX_Windows_SDK_2.1.100.46348.exe" included in the zip file.
2.	Enter the directory "Ankr" and double-click the executable "AnkrAlphaTest.exe". 
3.	Choose the "Ankr Demo"project to share you computing resource.
4.	Enjoy!
